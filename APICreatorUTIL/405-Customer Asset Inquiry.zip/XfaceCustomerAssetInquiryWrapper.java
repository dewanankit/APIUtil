
/*------------------------------------------------------------------------------
This source is part of the Oracle FLEXCUBE V.CO 4.5.0.0.0.0.0 Software System 
and is copyrighted by Oracle Financial Services Software Limited.
All rights reserved.  No part of this work may be reproduced,
stored in a retrieval system, adopted or transmitted in any form or
by any means,electronic, mechanical, photographic, graphic,
optic recording or otherwise,translated in any language or
computer language, without the prior written permission of
Oracle Financial Services Software Limited.
Oracle Financial Services Software Limited.
10-11, SDF I, SEEPZ, Andheri (East),
Mumbai - 400 096.
India
Copyright ? [2010] Oracle Financial Services Software Limited.
      $Revision$
      $LastChangedDate$
      $LastChangedBy$
      $HeadURL$
      $Id$ 
-------------------------------------------------------------------------------
Modification History
Date        Version     Author          Description
----------  ----------- --------------- ---------------------------------------
16/03/2012   1.0  		OFCR	 	Auto Generated Wrapper - Initial Version           
-------------------------------------------------------------------------------*/

package com.ofss.fc.xface.ext.wrapper.inquiry;


import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

import com.ofss.fc.app.Interaction;
import com.ofss.fc.app.context.SessionContext;
import com.ofss.fc.app.customer.dto.CustomerAssetLiabilityDTO;
import com.ofss.fc.xface.core.AbstractGenericWrapper;
import com.ofss.fc.common.CommonFAPIErrorConstants;
import com.ofss.fc.common.FCRJErrorConstants;
import com.ofss.fc.datatype.Date;
import com.ofss.fc.entity.transaction.TransactionStatus;
import com.ofss.fc.infra.error.ErrorManager;
import com.ofss.fc.infra.exception.FatalException;
import com.ofss.fc.infra.log.impl.TraceLogger;
import com.ofss.fc.infra.validation.error.ValidationError;
import com.ofss.fc.xface.entity.IXfaceTxnChnlXref;
import com.ofss.fc.xface.ext.dto.XfaceCustomerAssetInquiryRequestDTO;
import com.ofss.fc.xface.ext.dto.XfaceCustomerAssetInquiryResponseDTO;



public class XfaceCustomerAssetInquiryWrapper extends AbstractGenericWrapper {

	XfaceCustomerAssetInquiryWrapperImpl main_instance = new XfaceCustomerAssetInquiryWrapperImpl();

	
	public XfaceCustomerAssetInquiryResponseDTO processRequest(SessionContext  param1,
			XfaceCustomerAssetInquiryRequestDTO  param2) {
	
		Date requestTime = new Date();
		
		byte[] requestData = null;
		byte[] responseData = null;
		byte[] enrichedRequestData = null;
				
		XfaceCustomerAssetInquiryResponseDTO xfaceCustomerAssetInquiryResponseDTO = new XfaceCustomerAssetInquiryResponseDTO();
			
			TransactionStatus status = fetchTransactionStatus();		
			xfaceCustomerAssetInquiryResponseDTO.setTransactionStatus(status);
			
			try{
				Interaction.begin(param1);
				if (param2 == null) {
					ErrorManager.throwFatalException(CommonFAPIErrorConstants.MID_EGL_BLANK_FIELDS, null);
				}
				IXfaceTxnChnlXref xfaceTxnChnlXref = loadTransactionChannelXref(param1);
				Interaction.markCurrentTask(xfaceTxnChnlXref.getCodTask());
				requestData = serializeDTO(param2);
				
				TraceLogger.performance(XfaceCustomerAssetInquiryWrapper.class.getCanonicalName(), "", "Start of populateRequestTable : Start time " + System.currentTimeMillis () );
				HashMap requestHash = populateRequestTable(param2);
				TraceLogger.performance(XfaceCustomerAssetInquiryWrapper.class.getCanonicalName(), "", "End of populateRequestTable : End time " + System.currentTimeMillis () );
				
				ArrayList validationCodes = new ArrayList();
			
				if(param2.getValidationFlag() != null){
					String valCodes[] = param2.getValidationFlag().trim().split("(?<=\\G.{5})");
					validationCodes.addAll(Arrays.asList(valCodes));
				}
			
				TraceLogger.performance(XfaceCustomerAssetInquiryWrapper.class.getCanonicalName(), "", "Start of validation engine : Start time " + System.currentTimeMillis () );
				ValidationError[] errors = processRequest(	param1,
															param2, 			
															requestHash, 
															validationCodes);
				TraceLogger.performance(XfaceCustomerAssetInquiryWrapper.class.getCanonicalName(), "", "End of validation engine : End time " + System.currentTimeMillis () );
	
				if(errors  == null || errors.length == 0){
					
					TraceLogger.performance(XfaceCustomerAssetInquiryWrapper.class.getCanonicalName(), "", "Start of populateRequestDTO : Start time " + System.currentTimeMillis () );
					param2 = populateRequestDTO(requestHash, param2);
					TraceLogger.performance(XfaceCustomerAssetInquiryWrapper.class.getCanonicalName(), "", "End of populateRequestDTO : End time " + System.currentTimeMillis () );
					
					enrichedRequestData = serializeDTO(param2);
				
					
					xfaceCustomerAssetInquiryResponseDTO = main_instance.processRequest(
						param1,
						param2
					); 
					
					if(xfaceCustomerAssetInquiryResponseDTO != null && isResponseEnrichmentRequired(param1)){
						/*Populate the response hashmap from the response dto*/
						TraceLogger.performance(XfaceCustomerAssetInquiryWrapper.class.getCanonicalName(), "", "Start of populateResponseTable : Start time " + System.currentTimeMillis () );
						HashMap responseHash = populateResponseTable(xfaceCustomerAssetInquiryResponseDTO);
						TraceLogger.performance(XfaceCustomerAssetInquiryWrapper.class.getCanonicalName(), "", "End of populateResponseTable : End time " + System.currentTimeMillis () );
						
						TraceLogger.performance(XfaceCustomerAssetInquiryWrapper.class.getCanonicalName(), "", "Start of doResponseEnrichment : Start time " + System.currentTimeMillis () );
						doResponseEnrichment(	param1, 
								xfaceCustomerAssetInquiryResponseDTO, 
												responseHash);
						TraceLogger.performance(XfaceCustomerAssetInquiryWrapper.class.getCanonicalName(), "", "End of doResponseEnrichment : End time " + System.currentTimeMillis () );						
						
						/*populate response DTO from responseHash*/
						TraceLogger.performance(XfaceCustomerAssetInquiryWrapper.class.getCanonicalName(), "", "Start of populateResponseDTO : Start time " + System.currentTimeMillis () );
						xfaceCustomerAssetInquiryResponseDTO = populateResponseDTO(responseHash, xfaceCustomerAssetInquiryResponseDTO);						
						TraceLogger.performance(XfaceCustomerAssetInquiryWrapper.class.getCanonicalName(), "", "End of populateResponseDTO : End time " + System.currentTimeMillis () );
					}
				}else{
					status.setValidationErrors(errors);
					status.setExternalReferenceNo(param1.getExternalReferenceNo());
					status.setErrorCode(FCRJErrorConstants.MID_VALIDATION_FAILED);
					status.setReplyCode(Long.parseLong(ErrorManager.DEFAULT_ERR_RESPONSE.getEnumValue()));
					status.setReplyText(ErrorManager.buildErrorMessage(FCRJErrorConstants.MID_VALIDATION_FAILED, new String[]{String.valueOf(errors.length)}, null));					
				}
			}catch (FatalException e ){
				ErrorManager.logException(param1.getServiceCode(), e);
				fillTransactionStatus(xfaceCustomerAssetInquiryResponseDTO.getTransactionStatus(), e);			
			} catch (Throwable e) {
				ErrorManager.logException(param1.getServiceCode(), e);
				fillTransactionStatus(xfaceCustomerAssetInquiryResponseDTO.getTransactionStatus(), e);			
			} finally {
				Date responseTime = new Date();
				try{
					xfaceCustomerAssetInquiryResponseDTO.setPostingDate(param1.getPostingDateText().substring(0,8));
					responseData = serializeDTO(xfaceCustomerAssetInquiryResponseDTO);					
					TraceLogger.performance(XfaceCustomerAssetInquiryWrapper.class.getCanonicalName(), "", "Start of doDTOlogging : Start time " + System.currentTimeMillis () );
					doDTOlogging(	param1,
									requestData, 
									requestTime, 
									responseTime,
									responseData,
									enrichedRequestData);
					TraceLogger.performance(XfaceCustomerAssetInquiryWrapper.class.getCanonicalName(), "", "End of doDTOlogging : End time " + System.currentTimeMillis () );
				}catch(Throwable e){
					ErrorManager.logException(param1.getServiceCode(), e);
				}finally{
					try{
						Interaction.close();
					}catch(FatalException e){
						ErrorManager.logException(param1.getServiceCode(), e);
					}
				}
			}
			return xfaceCustomerAssetInquiryResponseDTO;

	}
	
	private XfaceCustomerAssetInquiryResponseDTO populateResponseDTO(
			HashMap hashMap,
			XfaceCustomerAssetInquiryResponseDTO  param3) {
		
								CustomerAssetLiabilityDTO[] customerAssetLiabilityDTOArray = (CustomerAssetLiabilityDTO[]) hashMap.get("XfaceCustomerAssetInquiryResponseDTO/customerAssetLiabilityDTOArray");
								
								param3.setNetAsset((BigDecimal) hashMap.get("XfaceCustomerAssetInquiryResponseDTO/netAsset"));
								param3.setNetLiability((BigDecimal) hashMap.get("XfaceCustomerAssetInquiryResponseDTO/NetLiability"));
								for(int i=0; i < customerAssetLiabilityDTOArray.length; i++)
								{
									CustomerAssetLiabilityDTO currentCustomerAssetLiabilityDTO = new CustomerAssetLiabilityDTO();
									currentCustomerAssetLiabilityDTO.setProductCode((int)hashMap.get("XfaceCustomerAssetInquiryResponseDTO/customerAssetLiabilityDTOArray/customerAssetLiabilityDTO/productCode"+i));
									currentCustomerAssetLiabilityDTO.setProductName((String)hashMap.get("XfaceCustomerAssetInquiryResponseDTO/customerAssetLiabilityDTOArray/customerAssetLiabilityDTO/productName"+i));
									currentCustomerAssetLiabilityDTO.setCustomerLiability((BigDecimal)hashMap.get("XfaceCustomerAssetInquiryResponseDTO/customerAssetLiabilityDTOArray/customerAssetLiabilityDTO/customerLiability"+i));
									currentCustomerAssetLiabilityDTO.setCustomerAsset((BigDecimal)hashMap.get("XfaceCustomerAssetInquiryResponseDTO/customerAssetLiabilityDTOArray/customerAssetLiabilityDTO/customerAsset"+i));
									currentCustomerAssetLiabilityDTO.setCurrencyCode((int)hashMap.get("XfaceCustomerAssetInquiryResponseDTO/customerAssetLiabilityDTOArray/customerAssetLiabilityDTO/currencyCode"+i));
									customerAssetLiabilityDTOArray[i] = currentCustomerAssetLiabilityDTO;
								}
								param3.setCustomerAssetLiabilityDTOArray(customerAssetLiabilityDTOArray);
							
		return param3;
		
	}
	
	private XfaceCustomerAssetInquiryRequestDTO populateRequestDTO(
			HashMap hashMap, XfaceCustomerAssetInquiryRequestDTO param3) {
			
		
								param3.setCustomerID( (int) hashMap.get("XfaceCustomerAssetInquiryRequestDTO/customerID"));
								param3.setLCYCode((String) hashMap.get("XfaceCustomerAssetInquiryRequestDTO/LCYCode"));
								
		return param3;
	}		
	
	private HashMap populateRequestTable(XfaceCustomerAssetInquiryRequestDTO param1){
		HashMap validation_map = new HashMap();
						int a = param1.getCustomerID();
						validation_map.put("XfaceCustomerAssetInquiryRequestDTO/customerID",param1.getCustomerID());
						validation_map.put("XfaceCustomerAssetInquiryRequestDTO/LCYCode",param1.getLCYCode());
					
		return validation_map;
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private  HashMap populateResponseTable(XfaceCustomerAssetInquiryResponseDTO  param1){	
		
		HashMap validation_map = new HashMap();
								
//						validation_map.put("XfaceLoanAccountBalanceInquiryResponseDTO/flgTellerAccess",param1.getFlgTellerAccess());
						validation_map.put("XfaceCustomerAssetInquiryResponseDTO/netAsset", param1.getNetAsset());
						validation_map.put("XfaceCustomerAssetInquiryResponseDTO/NetLiability", param1.getNetLiability());
						validation_map.put("XfaceCustomerAssetInquiryResponseDTO/customerAssetLiabilityDTOArray", param1.getCustomerAssetLiabilityDTOArray());
						CustomerAssetLiabilityDTO[] customerAssetLiabilityDTOArray = param1.getCustomerAssetLiabilityDTOArray();
						int i = 0;
						for(CustomerAssetLiabilityDTO currentCustomerAssetLiabilityDTO : customerAssetLiabilityDTOArray)
						{
							validation_map.put("XfaceCustomerAssetInquiryResponseDTO/customerAssetLiabilityDTOArray/customerAssetLiabilityDTO"+i, currentCustomerAssetLiabilityDTO);
							validation_map.put("XfaceCustomerAssetInquiryResponseDTO/customerAssetLiabilityDTOArray/customerAssetLiabilityDTO/productCode"+i, currentCustomerAssetLiabilityDTO.getProductCode());
							validation_map.put("XfaceCustomerAssetInquiryResponseDTO/customerAssetLiabilityDTOArray/customerAssetLiabilityDTO/productName"+i, currentCustomerAssetLiabilityDTO.getProductName());
							validation_map.put("XfaceCustomerAssetInquiryResponseDTO/customerAssetLiabilityDTOArray/customerAssetLiabilityDTO/customerLiability"+i, currentCustomerAssetLiabilityDTO.getCustomerLiability());
							validation_map.put("XfaceCustomerAssetInquiryResponseDTO/customerAssetLiabilityDTOArray/customerAssetLiabilityDTO/customerAsset"+i, currentCustomerAssetLiabilityDTO.getCustomerAsset());
							validation_map.put("XfaceCustomerAssetInquiryResponseDTO/customerAssetLiabilityDTOArray/customerAssetLiabilityDTO/currencyCode"+i, currentCustomerAssetLiabilityDTO.getCurrencyCode());
							i++;
						}
							
							
							
//											
//						validation_map.put("XfaceLoanAccountBalanceInquiryResponseDTO/customerShortName",param1.getCustomerShortName());
//											
//						validation_map.put("XfaceLoanAccountBalanceInquiryResponseDTO/accountCurrency",param1.getAccountCurrency());
//											
//						validation_map.put("XfaceLoanAccountBalanceInquiryResponseDTO/maturityDate",param1.getMaturityDate());
//											
//						validation_map.put("XfaceLoanAccountBalanceInquiryResponseDTO/accountStatus",param1.getAccountStatus());
//											
//						validation_map.put("XfaceLoanAccountBalanceInquiryResponseDTO/nextDueDate",param1.getNextDueDate());
//											
//						validation_map.put("XfaceLoanAccountBalanceInquiryResponseDTO/nextInstallmentDate",param1.getNextInstallmentDue());
//											
//						validation_map.put("XfaceLoanAccountBalanceInquiryResponseDTO/principalBalance",param1.getPrincipalBalance());
//											
//						validation_map.put("XfaceLoanAccountBalanceInquiryResponseDTO/unbilledPrincipalBalance",param1.getUnbilledPrincipalBalance());
//											
//						validation_map.put("XfaceLoanAccountBalanceInquiryResponseDTO/amountDisbursedToday",param1.getAmountDisbursedToday());
//											
//						validation_map.put("XfaceLoanAccountBalanceInquiryResponseDTO/futureInterest",param1.getFutureInterest());
//											
//						validation_map.put("XfaceLoanAccountBalanceInquiryResponseDTO/installmentArrears",param1.getInstallmentArrears());
//											
//						validation_map.put("XfaceLoanAccountBalanceInquiryResponseDTO/otherArrears",param1.getOtherArrears());
//											
//						validation_map.put("XfaceLoanAccountBalanceInquiryResponseDTO/minAmountDue",param1.getMinAmountDue());
//											
//						validation_map.put("XfaceLoanAccountBalanceInquiryResponseDTO/uncollectedInterest",param1.getUncollectedInterest());
//											
//						validation_map.put("XfaceLoanAccountBalanceInquiryResponseDTO/unbilledPenaltyInterest",param1.getUnbilledPenaltyInterest());
//											
//						validation_map.put("XfaceLoanAccountBalanceInquiryResponseDTO/unbilledServiceCharge",param1.getUnbilledServiceCharge());
//											
//						validation_map.put("XfaceLoanAccountBalanceInquiryResponseDTO/amountPaidToday",param1.getAmountPaidToday());
//											
//						validation_map.put("XfaceLoanAccountBalanceInquiryResponseDTO/rpaBalance",param1.getRpaBalance());
//											
//						validation_map.put("XfaceLoanAccountBalanceInquiryResponseDTO/unbilledInterest",param1.getUnbilledInterest());
//											
//						validation_map.put("XfaceLoanAccountBalanceInquiryResponseDTO/unbilledAdditionalPenaltyInterest",param1.getUnbilledAdditionalPenaltyInterest());
//											
//						validation_map.put("XfaceLoanAccountBalanceInquiryResponseDTO/unclearedFunds",param1.getUnclearedFunds());
//											
//						validation_map.put("XfaceLoanAccountBalanceInquiryResponseDTO/availableBalance",param1.getAvailableBalance());
//											
//						validation_map.put("XfaceLoanAccountBalanceInquiryResponseDTO/totalOutstandings",param1.getTotalOutstandings());
//											
//						validation_map.put("XfaceLoanAccountBalanceInquiryResponseDTO/suspendedInterestOnArrears",param1.getSuspendedInterestOnArrears());
//											
//						validation_map.put("XfaceLoanAccountBalanceInquiryResponseDTO/interestOnArrears",param1.getInterestOnArrears());
//											
//						validation_map.put("XfaceLoanAccountBalanceInquiryResponseDTO/pmiArrears",param1.getPmiArrears());
//											
//						validation_map.put("XfaceLoanAccountBalanceInquiryResponseDTO/suspenededPMIArrears",param1.getSuspenededPMIArrears());
//											
//						validation_map.put("XfaceLoanAccountBalanceInquiryResponseDTO/compoundingInterestArrears",param1.getCompoundingInterestArrears());
//											
//						validation_map.put("XfaceLoanAccountBalanceInquiryResponseDTO/divertingInterestArrears",param1.getDivertingInterestArrears());
					
		return validation_map;
	}

}
