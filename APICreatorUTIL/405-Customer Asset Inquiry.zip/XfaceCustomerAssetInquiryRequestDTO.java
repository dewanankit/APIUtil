/*------------------------------------------------------------------------------
This source is part of the Oracle FLEXCUBE V.CO 4.5.0.0.0.0.0 Software System 
and is copyrighted by Oracle Financial Services Software Limited.
All rights reserved.  No part of this work may be reproduced,
stored in a retrieval system, adopted or transmitted in any form or
by any means,electronic, mechanical, photographic, graphic,
optic recording or otherwise,translated in any language or
computer language, without the prior written permission of
Oracle Financial Services Software Limited.
Oracle Financial Services Software Limited.
10-11, SDF I, SEEPZ, Andheri (East),
Mumbai - 400 096.
India
Copyright ??? [2012] Oracle Financial Services Software Limited.
      $Revision$
      $LastChangedDate$
      $LastChangedBy$
      $HeadURL$
      $Id$
-------------------------------------------------------------------------------
Modification History
Date        	Version      Author          Description
----------   ----------- --------------- ---------------------------------------
18-02-2016  1.0  		  OFCR	 	 Auto Generated Unit - Initial Version
-------------------------------------------------------------------------------*/

package com.ofss.fc.xface.ext.dto;

import com.ofss.fc.xface.dto.common.XfaceGenericRequestDTO;


/**
 * This request is for : Loan_acct_balance_Inquiry
 * 
 * This request DTO is mapped to interface document: 406-Loan_acct_balance_Inquiry-version1.0.xls
 * 
 */
public class XfaceCustomerAssetInquiryRequestDTO
    extends XfaceGenericRequestDTO
{

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

    
    private int customerID;
    private String LCYCode;
	/**
	 * @return the customerID
	 */
	public int getCustomerID() {
		return customerID;
	}
	/**
	 * @param customerID the customerID to set
	 */
	public void setCustomerID(int customerID) {
		this.customerID = customerID;
	}
	
	/**
	 * @return the lCYCode
	 */
	public String getLCYCode() {
		return LCYCode;
	}
	/**
	 * @param lCYCode the lCYCode to set
	 */
	public void setLCYCode(String lCYCode) {
		LCYCode = lCYCode;
	}
}
