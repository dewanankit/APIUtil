
/*------------------------------------------------------------------------------
This source is part of the Oracle FLEXCUBE V.CO 4.5.0.0.0.0.0 Software System 
and is copyrighted by Oracle Financial Services Software Limited.
All rights reserved.  No part of this work may be reproduced,
stored in a retrieval system, adopted or transmitted in any form or
by any means,electronic, mechanical, photographic, graphic,
optic recording or otherwise,translated in any language or
computer language, without the prior written permission of
Oracle Financial Services Software Limited.
Oracle Financial Services Software Limited.
10-11, SDF I, SEEPZ, Andheri (East),
Mumbai - 400 096.
India
Copyright ? [2010] Oracle Financial Services Software Limited.
      $Revision$
      $LastChangedDate$
      $LastChangedBy$
      $HeadURL$
      $Id$ 
-------------------------------------------------------------------------------
Modification History
Date        Version     Author          Description
----------  ----------- --------------- ---------------------------------------
16/03/2012   1.0  		OFCR	 	Auto Generated Wrapper - Initial Version           
-------------------------------------------------------------------------------*/

package com.ofss.fc.xface.ext.wrapper.inquiry;

import com.ofss.fc.app.Interaction;
import com.ofss.fc.app.context.SessionContext;
import com.ofss.fc.app.customer.CustomerManager;
import com.ofss.fc.app.customer.ICustomerManager;
import com.ofss.fc.app.customer.dto.AssetLiabilityResponse;
import com.ofss.fc.app.customer.dto.CustomerAssetLiabilityDTO;
import com.ofss.fc.app.customer.dto.CustomerNetAssetLiabilityDTO;
import com.ofss.fc.datatype.Date;
import com.ofss.fc.entity.transaction.TransactionStatus;
import com.ofss.fc.infra.error.ErrorManager;
import com.ofss.fc.infra.exception.FatalException;
import com.ofss.fc.xface.common.AbstractXfaceApplication;
import com.ofss.fc.xface.ext.common.XfaceExtErrorConstants;
import com.ofss.fc.xface.ext.dto.XfaceCustomerAssetInquiryRequestDTO;
import com.ofss.fc.xface.ext.dto.XfaceCustomerAssetInquiryResponseDTO;
import com.ofss.fc.xface.ext.wrapper.helper.XfaceExtGlobalDatabseMapping;


public class XfaceCustomerAssetInquiryWrapperImpl extends AbstractXfaceApplication {

	
	@SuppressWarnings("unused")
	public XfaceCustomerAssetInquiryResponseDTO processRequest(SessionContext sessionContext, XfaceCustomerAssetInquiryRequestDTO request) throws FatalException {
	
			final String METHOD_NAME = "processRequest";	
			XfaceCustomerAssetInquiryResponseDTO xfaceCustomerAssetInquiryResponseDTO = new XfaceCustomerAssetInquiryResponseDTO();
			
			TransactionStatus status = fetchTransactionStatus();
			String serviceCode = 	sessionContext.getServiceCode();
			XfaceExtGlobalDatabseMapping databasemapping = new XfaceExtGlobalDatabseMapping();
			try{
				Interaction.begin(sessionContext);
				if(request.getCustomerID() == 0)
				{
					ErrorManager.throwFatalException(XfaceExtErrorConstants.CUST_ID_BLANK, null);
				}
				if(request.getLCYCode() == null)
				{
					ErrorManager.throwFatalException(XfaceExtErrorConstants.CUST_ID_BLANK, null);
				}
				ICustomerManager customerManager = new CustomerManager();
				
				AssetLiabilityResponse assetLiabilityResponse = customerManager.inquireCustomerAssetLiability(sessionContext, Integer.toString(request.getCustomerID()), request.getLCYCode());
				
				xfaceCustomerAssetInquiryResponseDTO.setCustomerAssetLiabilityDTOArray(assetLiabilityResponse.getCustomerAssetLiabilityResponseDTO());
				xfaceCustomerAssetInquiryResponseDTO.setNetAsset(assetLiabilityResponse.getCustomerNetAssetLiabilityDTO().getNetAsset());
				xfaceCustomerAssetInquiryResponseDTO.setNetLiability(assetLiabilityResponse.getCustomerNetAssetLiabilityDTO().getNetAsset());
				
			}catch (FatalException e ){
				ErrorManager.logException(sessionContext.getServiceCode(), e);
				fillTransactionStatus(xfaceCustomerAssetInquiryResponseDTO.getTransactionStatus(), e);			
			} catch (Throwable e) {
				ErrorManager.logException(sessionContext.getServiceCode(), e);
				fillTransactionStatus(xfaceCustomerAssetInquiryResponseDTO.getTransactionStatus(), e);			
			} finally {
				Interaction.close();
			}
			return xfaceCustomerAssetInquiryResponseDTO;
	}
	
}
